# Hack_hive_version2_using_gemini
In this repo i used the gemini model to give additional info about the waaste generated and give tbe user info about the disposal knowledge

the api key should be stoored in a .env file and the makeup shall be like the below stated
GENAI_API_KEY=your_actual_api_key_here


